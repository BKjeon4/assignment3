import { Container, Row, Col, Button } from "react-bootstrap";
import { useAtom } from "jotai";
import { favouritesAtom } from "@/store";
import { useState } from "react";

export default function BookDetails({book,workId,showFavouriteBtn=true}){

  const [favourites,setFavourites] = useAtom(favouritesAtom);

  const [added,setAdded] = useState(
    favourites.includes(workId)
  );

  const toggleFav = ()=>{

    if(added){

      setFavourites(curr=>curr.filter(f=>f!==workId));
      setAdded(false);

    }else{

      setFavourites(curr=>[...curr,workId]);
      setAdded(true);

    }

  };

  if(!book) return null;

  return(
    <Container>

      <Row>

        <Col lg={4}>

          <img
            className="img-fluid w-100"
            src={`https://covers.openlibrary.org/b/id/${book?.covers?.[0]}-L.jpg`}
            onError={(e)=>{
              e.target.src="https://placehold.co/400x600?text=No+Cover"
            }}
          />

        </Col>

        <Col lg={8}>

          <h3>{book.title}</h3>

          {book.description && (
            <p>
              {typeof book.description==="string"
                ? book.description
                : book.description.value}
            </p>
          )}

          {book.subject_people && (
            <>
              <h5>Characters</h5>
              <p>{book.subject_people.join(", ")}</p>
            </>
          )}

          {book.subject_places && (
            <>
              <h5>Settings</h5>
              <p>{book.subject_places.join(", ")}</p>
            </>
          )}

          {book.links && (
            <>
              <h5>More Information</h5>

              {book.links.map((l,i)=>(
                <div key={i}>
                  <a href={l.url} target="_blank">{l.title}</a>
                </div>
              ))}

            </>
          )}

          {showFavouriteBtn && (

            <Button
              variant={added ? "primary" : "outline-primary"}
              onClick={toggleFav}
            >
              {added ? "+ Favourite (added)" : "+ Favourite"}
            </Button>

          )}

        </Col>

      </Row>

    </Container>
  );
}
import { Navbar, Nav, Container } from "react-bootstrap";
import Link from "next/link";

export default function MainNav() {

  return (
    <Navbar bg="dark" variant="dark" expand="lg" fixed="top">
      <Container>

        <Navbar.Brand as={Link} href="/">
          Byungwook Jeon
        </Navbar.Brand>

        <Nav className="me-auto">

          {/* <Nav.Link as={Link} href="/">
            Books
          </Nav.Link> */}

          <Nav.Link as={Link} href="/about">
            About
          </Nav.Link>

          <Nav.Link as={Link} href="/favourites">
            Favourites
          </Nav.Link>

        </Nav>

      </Container>
    </Navbar>
  );

}